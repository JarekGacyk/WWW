<?php
$dsn = 'mysql:host=localhost;dbname=moja_strona;charset=utf8mb4';
$username = 'root'; // lub inna nazwa użytkownika
$password = ''; // hasło do bazy danych
try {
    $pdo = new PDO($dsn, $username, $password);
    echo "Połączenie działa!";
} catch (PDOException $e) {
    echo "Błąd połączenia: " . $e->getMessage();
}
?>
