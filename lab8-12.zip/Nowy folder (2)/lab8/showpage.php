<?php
include 'cfg.php'; // Import konfiguracji bazy danych

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM pages WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $page = $stmt->fetch();

        if ($page) {
            echo "<h1>" . htmlspecialchars($page['title']) . "</h1>";
            echo "<div>" . htmlspecialchars($page['content']) . "</div>";
        } else {
            echo "<p>Nie znaleziono strony.</p>";
        }
    } catch (PDOException $e) {
        echo "<p>Błąd: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>Nie podano ID strony.</p>";
}
?>
