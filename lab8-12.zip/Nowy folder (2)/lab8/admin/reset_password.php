<?php
session_start();
include '../contact.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo '
    <h2>Resetowanie hasła</h2>
    <form method="POST" action="reset_password.php">
        <label for="email">Podaj swój adres e-mail:</label>
        <input type="email" name="email" id="email" required>
        <button type="submit" name="send_reset">Wyślij przypomnienie hasła</button>
    </form>
    <a href="admin.php">Powrót</a>';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_reset'])) {
        $email = htmlspecialchars($_POST['email']);
        PrzypomnijHaslo($email);
        echo "<p>Wiadomość z przypomnieniem hasła została wysłana na adres: $email</p>";
        echo '<a href="admin.php">Powrót do logowania</a>';
        exit;
    }
}
?>
