<?php
// Start a session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "moja_strona";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle add page
if (isset($_POST['add_page'])) {
    $page_title = $_POST['page_title'];
    $page_content = $_POST['page_content'];

    $sql = "INSERT INTO page_list (page_title, page_content, created_at) VALUES (?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $page_title, $page_content);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Page added successfully!";
    } else {
        $_SESSION['message'] = "Error adding page: " . $stmt->error;
    }
    header("Location: admin_categories.php");
    exit;
}

// Handle edit page
if (isset($_POST['edit_page'])) {
    $id = $_POST['id'];
    $page_title = $_POST['page_title'];
    $page_content = $_POST['page_content'];

    $sql = "UPDATE page_list SET page_title = ?, page_content = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $page_title, $page_content, $id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Page updated successfully!";
    } else {
        $_SESSION['message'] = "Error updating page: " . $stmt->error;
    }
    header("Location: admin_categories.php");
    exit;
}

// Handle delete page
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM page_list WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Page deleted successfully!";
    } else {
        $_SESSION['message'] = "Error deleting page: " . $stmt->error;
    }
    header("Location: admin_categories.php");
    exit;
}

// Fetch all pages
$sql = "SELECT * FROM page_list";
$result = $conn->query($sql);
if (!$result) {
    die("Error fetching pages: " . $conn->error);
}
$pages = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Pages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }
        h1 {
            text-align: center;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        table th {
            background-color: #007bff;
            color: #fff;
        }
        form {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        form div {
            margin-bottom: 15px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
        }
        form input, form textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        form button {
            padding: 10px 15px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .delete-button, .edit-button {
            padding: 5px 10px;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .delete-button {
            background-color: #dc3545;
        }
        .edit-button {
            background-color: #007bff;
        }
        .message {
            width: 80%;
            margin: 20px auto;
            padding: 10px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Manage Pages</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="message">
            <?= $_SESSION['message'] ?>
        </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form method="POST" action="">
        <h2>Add Page</h2>
        <div>
            <label for="page_title">Page Title</label>
            <input type="text" name="page_title" id="page_title" required>
        </div>
        <div>
            <label for="page_content">Page Content</label>
            <textarea name="page_content" id="page_content" rows="5" required></textarea>
        </div>
        <button type="submit" name="add_page">Add Page</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Page Title</th>
            <th>Page Content</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($pages as $page): ?>
            <tr>
                <td><?= $page['id'] ?></td>
                <td><?= $page['page_title'] ?></td>
                <td><?= substr($page['page_content'], 0, 50) ?>...</td>
                <td><?= $page['created_at'] ?></td>
                <td>
                    <a href="?delete=<?= $page['id'] ?>" class="delete-button">Delete</a>
                    <a href="edit_page.php?id=<?= $page['id'] ?>" class="edit-button">Edit</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
