<?php
// Start a session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "moja_strona";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle add category
if (isset($_POST['add_category'])) {
    $category_name = $_POST['category_name'];
    $parent_id = $_POST['parent_id'];

    $sql = "INSERT INTO categoriess (name, parent_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $category_name, $parent_id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Category added successfully!";
    } else {
        $_SESSION['message'] = "Error adding category: " . $stmt->error;
    }
    header("Location: manage_categories.php");
    exit;
}

// Handle delete category
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM categoriess WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Category deleted successfully!";
    } else {
        $_SESSION['message'] = "Error deleting category: " . $stmt->error;
    }
    header("Location: manage_categories.php");
    exit;
}

// Fetch all categories
$sql = "SELECT * FROM categoriess";
$result = $conn->query($sql);
if (!$result) {
    die("Error fetching categories: " . $conn->error);
}
$categories = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }
        h1 {
            text-align: center;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        table th {
            background-color: #007bff;
            color: #fff;
        }
        form {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        form div {
            margin-bottom: 15px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
        }
        form input, form select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        form button {
            padding: 10px 15px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .delete-button {
            padding: 5px 10px;
            color: #fff;
            background-color: #dc3545;
            text-decoration: none;
            border-radius: 5px;
        }
        .message {
            width: 80%;
            margin: 20px auto;
            padding: 10px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Manage Categories</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="message">
            <?= $_SESSION['message'] ?>
        </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form method="POST" action="">
        <h2>Add Category</h2>
        <div>
            <label for="category_name">Category Name</label>
            <input type="text" name="category_name" id="category_name" required>
        </div>
        <div>
            <label for="parent_id">Parent Category</label>
            <select name="parent_id" id="parent_id">
                <option value="0">None</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= $category['id'] ?>"><?= $category['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" name="add_category">Add Category</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Parent ID</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($categories as $category): ?>
            <tr>
                <td><?= $category['id'] ?></td>
                <td><?= $category['name'] ?></td>
                <td><?= $category['parent_id'] ?></td>
                <td>
                    <a href="?delete=<?= $category['id'] ?>" class="delete-button">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
