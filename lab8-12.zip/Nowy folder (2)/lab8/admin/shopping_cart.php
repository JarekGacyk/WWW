<?php
// Start a session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "moja_strona";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Function to add a product to the cart
function addToCart($productId, $quantity) {
    global $conn;
    $sql = "SELECT * FROM productss WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($product = $result->fetch_assoc()) {
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] === $productId) {
                $item['quantity'] += $quantity;
                return;
            }
        }
        $_SESSION['cart'][] = [
            'id' => $product['id'],
            'name' => $product['title'],
            'price' => $product['price_net'],
            'quantity' => $quantity
        ];
    } else {
        echo "<script>alert('Product not found.');</script>";
    }
}

// Function to remove a product from the cart
function removeFromCart($productId) {
    foreach ($_SESSION['cart'] as $index => $item) {
        if ($item['id'] === $productId) {
            unset($_SESSION['cart'][$index]);
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Re-index the array
            return;
        }
    }
}

// Function to show the cart contents
function showCart() {
    if (empty($_SESSION['cart'])) {
        echo "<p>Your cart is empty.</p>";
        return;
    }

    echo "<table class='cart-table'>";
    echo "<tr><th>Name</th><th>Price</th><th>Quantity</th><th>Total</th><th>Actions</th></tr>";
    $grandTotal = 0;
    foreach ($_SESSION['cart'] as $item) {
        $name = isset($item['name']) ? $item['name'] : 'Unknown';
        $price = isset($item['price']) ? $item['price'] : 0;
        $quantity = isset($item['quantity']) ? $item['quantity'] : 0;
        $total = $price * $quantity;
        $grandTotal += $total;
        echo "<tr>";
        echo "<td>{$name}</td>";
        echo "<td>\${$price}</td>";
        echo "<td>{$quantity}</td>";
        echo "<td>\${$total}</td>";
        echo "<td><a class='remove-button' href='?remove={$item['id']}'>Remove</a></td>";
        echo "</tr>";
    }
    echo "<tr><td colspan='3'><strong>Grand Total</strong></td><td colspan='2'><strong>\${$grandTotal}</strong></td></tr>";
    echo "</table>";
}

// Function to show products from the database
function showProducts() {
    global $conn;
    $sql = "SELECT * FROM productss";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "<div class='product-list'>";
        while ($row = $result->fetch_assoc()) {
            echo "<div class='product-item'>";
            echo "<h3>{$row['title']}</h3>";
            echo "<p>Price: \${$row['price_net']}</p>";
            echo "<a class='add-button' href='?add={$row['id']}'>Add to Cart</a>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No products available.</p>";
    }
}

// Handle add to cart action
if (isset($_GET['add'])) {
    $productId = intval($_GET['add']); // Ensure $productId is an integer
    $quantity = 1; // Default quantity
    addToCart($productId, $quantity);
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}

// Handle remove from cart action
if (isset($_GET['remove'])) {
    $productId = intval($_GET['remove']); // Ensure $productId is an integer
    removeFromCart($productId);
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }
        h1 {
            text-align: center;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
        }
        .cart-table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        .cart-table th, .cart-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        .cart-table th {
            background-color: #007bff;
            color: #fff;
        }
        .remove-button, .add-button {
            display: inline-block;
            padding: 5px 10px;
            color: #fff;
            background-color: #dc3545;
            text-decoration: none;
            border-radius: 5px;
        }
        .add-button {
            background-color: #28a745;
        }
        .product-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }
        .product-item {
            border: 1px solid #ddd;
            padding: 15px;
            text-align: center;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            width: 200px;
        }
        .product-item h3 {
            margin: 0 0 10px;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <h1>Shopping Cart</h1>

    <div>
        <?php showCart(); ?>
    </div>

    <div>
        <?php showProducts(); ?>
    </div>

</body>
</html>
