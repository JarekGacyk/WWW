<?php
// Start a session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "moja_strona";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle add product
if (isset($_POST['add_product'])) {
    $product_title = $_POST['product_title'];
    $product_description = $_POST['product_description'];
    $price_net = $_POST['price_net'];
    $vat = $_POST['vat'];
    $stock = $_POST['stock'];
    $availability_status = $_POST['availability_status'];
    $size = $_POST['size'];
    $image = $_POST['image'];
    $category_id = $_POST['category_id'];
    $expiration_date = $_POST['expiration_date'];

    // Format expiration_date to YYYY-MM-DD
    $formatted_date = date('Y-m-d', strtotime($expiration_date));

    $sql = "INSERT INTO productss (title, description, price_net, vat, stock, availability_status, size, image, category_id, expiration_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssddisssis", $product_title, $product_description, $price_net, $vat, $stock, $availability_status, $size, $image, $category_id, $formatted_date);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Product added successfully!";
    } else {
        $_SESSION['message'] = "Error adding product: " . $stmt->error;
    }
    header("Location: manage_products.php");
    exit;
}

// Fetch all products
$sql = "SELECT productss.id, productss.title, productss.description, productss.price_net, productss.vat, productss.stock, productss.availability_status, productss.size, productss.image, categoriess.name AS category_name, productss.expiration_date 
        FROM productss 
        LEFT JOIN categoriess ON productss.category_id = categoriess.id";
$result = $conn->query($sql);
if (!$result) {
    die("Error fetching products: " . $conn->error);
}
$products = $result->fetch_all(MYSQLI_ASSOC);

// Fetch all categories
$sql = "SELECT * FROM categoriess";
$result = $conn->query($sql);
if (!$result) {
    die("Error fetching categories: " . $conn->error);
}
$categories = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }
        h1 {
            text-align: center;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        table th {
            background-color: #007bff;
            color: #fff;
        }
        form {
            width: 90%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        form div {
            margin-bottom: 15px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
        }
        form input, form select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        form button {
            padding: 10px 15px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .delete-button {
            padding: 5px 10px;
            color: #fff;
            background-color: #dc3545;
            text-decoration: none;
            border-radius: 5px;
        }
        .message {
            width: 90%;
            margin: 20px auto;
            padding: 10px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Manage Products</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="message">
            <?= $_SESSION['message'] ?>
        </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form method="POST" action="">
        <h2>Add Product</h2>
        <div>
            <label for="product_title">Title</label>
            <input type="text" name="product_title" id="product_title" required>
        </div>
        <div>
            <label for="product_description">Description</label>
            <textarea name="product_description" id="product_description" rows="4" required></textarea>
        </div>
        <div>
            <label for="price_net">Net Price</label>
            <input type="number" step="0.01" name="price_net" id="price_net" required>
        </div>
        <div>
            <label for="vat">VAT</label>
            <input type="number" step="0.01" name="vat" id="vat" required>
        </div>
        <div>
            <label for="stock">Stock</label>
            <input type="number" name="stock" id="stock" required>
        </div>
        <div>
            <label for="availability_status">Availability Status</label>
            <input type="text" name="availability_status" id="availability_status" required>
        </div>
        <div>
            <label for="size">Size</label>
            <input type="text" name="size" id="size" required>
        </div>
        <div>
            <label for="image">Image URL</label>
            <input type="text" name="image" id="image">
        </div>
        <div>
            <label for="category_id">Category</label>
            <select name="category_id" id="category_id" required>
                <option value="">Select Category</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= $category['id'] ?>"><?= $category['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="expiration_date">Expiration Date</label>
            <input type="date" name="expiration_date" id="expiration_date" required>
        </div>
        <button type="submit" name="add_product">Add Product</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Net Price</th>
            <th>VAT</th>
            <th>Stock</th>
            <th>Availability</th>
            <th>Size</th>
            <th>Image</th>
            <th>Category</th>
            <th>Expiration Date</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($products as $product): ?>
            <tr>
                <td><?= $product['id'] ?></td>
                <td><?= $product['title'] ?></td>
                <td><?= $product['description'] ?></td>
                <td>$<?= number_format($product['price_net'], 2) ?></td>
                <td><?= $product['vat'] ?>%</td>
                <td><?= $product['stock'] ?></td>
                <td><?= $product['availability_status'] ?></td>
                <td><?= $product['size'] ?></td>
                <td><img src="<?= $product['image'] ?>" alt="Image" style="width: 50px; height: auto;"></td>
                <td><?= $product['category_name'] ?></td>
                <td><?= $product['expiration_date'] ?></td>
                <td>
                    <a href="?delete=<?= $product['id'] ?>" class="delete-button">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
