<?php
session_start();
include '../cfg.php';
include '../contact.php'; // Dołączenie funkcji PrzypomnijHaslo

function FormularzLogowania($error = '') {
    echo "<h2>Logowanie do panelu administracyjnego</h2>";
    if ($error) {
        echo "<p style='color: red;'>$error</p>";
    }

    // Formularz logowania
    echo '<form method="POST" action="">
            <label for="login">Login:</label>
            <input type="text" name="login" id="login" required>
            <label for="password">Hasło:</label>
            <input type="password" name="password" id="password" required>
            <button type="submit" name="submit">Zaloguj</button>
            <a href="reset_password.php" style="text-decoration: none;">
                <button type="button">Przypomnij hasło</button>
            </a>
          </form>';
}

if (isset($_POST['reset_request'])) {
    // Po kliknięciu "Przypomnij hasło" wyświetl formularz do podania e-maila
    FormularzLogowania('', true);
    exit;
}

if (isset($_POST['send_reset'])) {
    // Obsługa wysyłki e-maila z hasłem
    $email = htmlspecialchars($_POST['email']);
    PrzypomnijHaslo($email);
    echo "<p>Wiadomość z przypomnieniem hasła została wysłana na adres: $email</p>";
    exit;
}

if (isset($_POST['cancel'])) {
    // Powrót do standardowego formularza logowania
    FormularzLogowania();
    exit;
}

if (isset($_POST['submit'])) {
    $login = htmlspecialchars($_POST['login']);
    $password = htmlspecialchars($_POST['password']);

    // Sprawdź dane z cfg.php
    if ($login === $adminLogin && $password === $adminPassword) {
        $_SESSION['logged_in'] = true;
        header('Location: admin.php');
    } else {
        FormularzLogowania('Błędny login lub hasło.');
        exit;
    }
}

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    FormularzLogowania();
    exit;
}

echo "<h1>Panel administracyjny</h1>";
echo '<nav>
        <a href="?action=list">Lista podstron</a> | 
        <a href="?action=add">Dodaj nową podstronę</a> | 
        <a href="?action=logout">Wyloguj</a>
      </nav>';

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'list':
            echo "<p>Lista podstron (do zaimplementowania).</p>";
            break;
        case 'add':
            echo "<p>Dodaj nową podstronę (do zaimplementowania).</p>";
            break;
        case 'logout':
            session_destroy();
            header('Location: admin.php');
            break;
        default:
            echo "<p>Nieznana akcja.</p>";
            break;
    }
}
?>

