<?php
include ('cfg.php');
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);


if (isset($_GET['idp'])) {
    switch ($_GET['idp']) {
        case '':
            $strona = 'html/glowna.html';
            break;
        case 'historia':
            $strona = 'html/historia.html';
            break;
        case 'galeria':
            $strona = 'html/galeria.html';
            break;
        case 'ciekawostki':
            $strona = 'html/ciekawostki.html';
            break;
        case 'kontakt':
            $strona = 'html/kontakt.html';
            break;
        case 'filmy':
            $strona = 'html/filmy.html';
            break;
        default:
            $strona = null;
            break;
    }
} else {
    $strona = 'html/glowna.html';
}


?>
<!DOCTYPE html>
<html lang="pl">
<head>
	
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Największe budynki świata</title>
    <link rel="stylesheet" href="css/styles.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/kolorujtlo.js" defer></script>
    <script src="js/timedate.js" defer></script>
</head>
<body onload="startclock()">
 <FORM METHOD="POST" NAME="background">
      <INPUT TYPE="button" VALUE="żółty" ONCLICK="changeBackground('#FFF000')">
      <INPUT TYPE="button" VALUE="czarny" ONCLICK="changeBackground('#000000')">
      <INPUT TYPE="button" VALUE="biały" ONCLICK="changeBackground('#FFFFFF')">
      <INPUT TYPE="button" VALUE="zielony" ONCLICK="changeBackground('#00FF00')">
      <INPUT TYPE="button" VALUE="niebieski" ONCLICK="changeBackground('#0000FF')">
      <INPUT TYPE="button" VALUE="pomarańczowy" ONCLICK="changeBackground('#FF8000')">
      <INPUT TYPE="button" VALUE="szary" ONCLICK="changeBackground('#C0C0C0')">
      <INPUT TYPE="button" VALUE="czerwony" ONCLICK="changeBackground('#FF0000')">
    </FORM>
    <header>
        <h1>Największe Budynki Świata</h1>
        <nav>
            <ul>
                <li><a href="index.php?idp=">Strona Główna</a></li>
                <li><a href="index.php?idp=historia">Historia Budownictwa</a></li>
                <li><a href="index.php?idp=galeria">Galeria</a></li>
                <li><a href="index.php?idp=ciekawostki">Ciekawostki</a></li>
                <li><a href="index.php?idp=kontakt">Kontakt</a></li>
                <li><a href="index.php?idp=filmy">Filmy</a></li>
            </ul>
        </nav>
    </header>

    <main>
		<section>
        <?php
        if ($strona !== null && file_exists($strona)) {
            include($strona);
        } else {
            include('html/404.html'); 
        }
        ?>
		</section>
		<section>
		<?php include 'showpage.php'; ?>
		</section>
    </main>

    <footer>
	<div style="text-align: center; margin-top: 20px;">
    <p>Data: <span id="data"></span></p>
    <p>Czas: <span id="zegarek"></span></p>
</div>

        <?php
        $nr_indeksu = '169238';
        $nrGrupy = '1';
        echo "Autor: Jarek Gacyk, $nr_indeksu, grupa $nrGrupy";
        ?>
    </footer>
</body>
</html>
