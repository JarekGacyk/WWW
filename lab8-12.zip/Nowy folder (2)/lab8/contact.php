<?php
// contact.php - wersja v1.7

// Funkcja do wyświetlania formularza kontaktowego
function PokazKontakt() {
    echo '
    <form action="contact.php" method="post">
        <label for="name">Imię:</label><br>
        <input type="text" id="name" name="name" required><br><br>
        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        <label for="message">Wiadomość:</label><br>
        <textarea id="message" name="message" required></textarea><br><br>
        <input type="submit" name="submit_contact" value="Wyślij">
    </form>';
}

// Funkcja do wysyłania e-maila z wiadomością z formularza
function WyslijMailKontakt($odbiorca) {
    if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['message'])) {
        echo "Nie wypełniono wszystkich pól.";
        PokazKontakt(); // ponowne wywołanie formularza
        return;
    }

    $mail['subject'] = "Formularz kontaktowy od: " . $_POST['name'];
    $mail['body'] = "Wiadomość od: " . $_POST['name'] . "\n" . "Email: " . $_POST['email'] . "\n\n" . "Treść: " . $_POST['message'];
    $mail['sender'] = $_POST['email'];

    $headers = "From: Formularz kontaktowy <" . $mail['sender'] . ">";
    $headers .= "\nMIME-Version: 1.0\nContent-type: text/plain; charset=utf-8";

    if (mail($odbiorca, $mail['subject'], $mail['body'], $headers)) {
        echo "<p>Wiadomość została wysłana!</p>";
    } else {
        echo "<p>Wystąpił błąd podczas wysyłania wiadomości.</p>";
    }
}

// Funkcja do wysyłania przypomnienia hasła
function PrzypomnijHaslo($adminEmail) {
    $mail['subject'] = "Przypomnienie hasła";
    $mail['body'] = "Twoje hasło do panelu admina to: admin123"; // Przykładowe hasło
    $mail['sender'] = "no-reply@example.com";

    $headers = "From: System <" . $mail['sender'] . ">";
    $headers .= "\nMIME-Version: 1.0\nContent-type: text/plain; charset=utf-8";

    if (mail($adminEmail, $mail['subject'], $mail['body'], $headers)) {
        echo "<p>Hasło zostało wysłane na e-mail administratora!</p>";
    } else {
        echo "<p>Wystąpił błąd podczas wysyłania hasła.</p>";
    }
}

// Obsługa formularza kontaktowego
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit_contact'])) {
        WyslijMailKontakt("your_email@example.com"); // Wstaw swój adres e-mail
    }
}
?>
