<?php
$nr_indeksu = '169238';
$nrGrupy = '1';
echo 'Jarek Gacyk '.$nr_indeksu.' grupa '.$nrGrupy.' <br /><br />';
echo "Demonstracja metody include() oraz require_once() w PHP<br>";

include('include.php');
require_once('require.php'); 

echo "Przykłady warunków if, else, elseif oraz switch<br>";

$number = 5;
if ($number > 10) {
    echo "Liczba jest większa niż 10<br>";
} elseif ($number == 10) {
    echo "Liczba jest równa 10<br>";
} else {
    echo "Liczba jest mniejsza niż 10<br>";
}

$day = "poniedziałek";
switch ($day) {
    case "poniedziałek":
        echo "Dzisiaj jest poniedziałek<br>";
        break;
    case "wtorek":
        echo "Dzisiaj jest wtorek<br>";
        break;
    default:
        echo "Dzisiaj nie jest ani poniedziałek, ani wtorek<br>";
        break;
}

echo "Przykład pętli while oraz for<br>";

$i = 0;
while ($i < 5) {
    echo "Liczba while: $i<br>";
    $i++;
}

for ($j = 0; $j < 5; $j++) {
    echo "Liczba for: $j<br>";
}

echo "Demonstracja typów zmiennych \$_GET, \$_POST oraz \$_SESSION<br>";

if (isset($_GET['name'])) {
    echo "Wartość przekazana przez \$_GET: " . htmlspecialchars($_GET['name']) . "<br>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email'])) {
        echo "Wartość przekazana przez \$_POST: " . htmlspecialchars($_POST['email']) . "<br>";
    }
}

session_start(); 
if (!isset($_SESSION['counter'])) {
    $_SESSION['counter'] = 1;
} else {
    $_SESSION['counter']++;
}
echo "Licznik sesji: " . $_SESSION['counter'] . "<br>";
?>