<?php

$host = 'localhost'; 
$dbname = 'moja_strona'; 
$username = 'root'; 
$password = ''; 





$adminLogin = 'admin'; 
$adminPassword = '123456'; 
?>
