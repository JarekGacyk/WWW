<?php
session_start();
include '../cfg.php';

function FormularzLogowania($error = '') {
    echo "<h2>Logowanie do panelu administracyjnego</h2>";
    if ($error) {
        echo "<p style='color: red;'>$error</p>";
    }
    echo '<form method="POST">
            <label for="login">Login:</label>
            <input type="text" name="login" id="login" required>
            <label for="password">Hasło:</label>
            <input type="password" name="password" id="password" required>
            <button type="submit" name="submit">Zaloguj</button>
          </form>';
}

if (isset($_POST['submit'])) {
    $login = htmlspecialchars($_POST['login']);
    $password = htmlspecialchars($_POST['password']);

    if ($login === $adminLogin && $password === $adminPassword) {
        $_SESSION['logged_in'] = true;
    } else {
        FormularzLogowania('Błędny login lub hasło.');
        exit;
    }
}

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    FormularzLogowania();
    exit;
}

function ListaPodstron() {
    global $pdo; // Używamy globalnej zmiennej $pdo

    echo "<h2>Lista podstron</h2>";
    echo '<table border="1">
            <tr>
                <th>ID</th>
                <th>Tytuł</th>
                <th>Opcje</th>
            </tr>';
    try {
        $stmt = $pdo->query("SELECT id, page_title FROM page_list WHERE status = 1");
        while ($row = $stmt->fetch()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['page_title']}</td>
                    <td>
                        <a href='?action=edit&id={$row['id']}'>Edytuj</a> | 
                        <a href='?action=delete&id={$row['id']}'>Usuń</a>
                    </td>
                  </tr>";
        }
    } catch (PDOException $e) {
        echo "<p>Błąd podczas pobierania danych: " . $e->getMessage() . "</p>";
    }
    echo '</table>';
}

function EdytujPodstrone($id) {
    global $pdo;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
        $title = htmlspecialchars($_POST['title']);
        $content = htmlspecialchars($_POST['content']);
        $status = isset($_POST['status']) ? 1 : 0;

        $stmt = $pdo->prepare("UPDATE page_list SET page_title = :title, page_content = :content, status = :status WHERE id = :id LIMIT 1");
        $stmt->execute(['title' => $title, 'content' => $content, 'status' => $status, 'id' => $id]);
        echo "<p>Podstrona została zaktualizowana.</p>";
    }

    $stmt = $pdo->prepare("SELECT * FROM page_list WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    $page = $stmt->fetch();

    echo '<form method="POST">
            <label for="title">Tytuł:</label>
            <input type="text" name="title" id="title" value="' . htmlspecialchars($page['page_title']) . '" required>
            <label for="content">Treść:</label>
            <textarea name="content" id="content" required>' . htmlspecialchars($page['page_content']) . '</textarea>
            <label for="status">Aktywna:</label>
            <input type="checkbox" name="status" id="status" ' . ($page['status'] ? 'checked' : '') . '>
            <button type="submit" name="update">Zapisz</button>
          </form>';
}

function DodajNowaPodstrone() {
    global $pdo;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
        $title = htmlspecialchars($_POST['title']);
        $content = htmlspecialchars($_POST['content']);
        $status = isset($_POST['status']) ? 1 : 0;

        $stmt = $pdo->prepare("INSERT INTO page_list (page_title, page_content, status) VALUES (:title, :content, :status)");
        $stmt->execute(['title' => $title, 'content' => $content, 'status' => $status]);
        echo "<p>Nowa podstrona została dodana.</p>";
    }

    echo '<form method="POST">
            <label for="title">Tytuł:</label>
            <input type="text" name="title" id="title" required>
            <label for="content">Treść:</label>
            <textarea name="content" id="content" required></textarea>
            <label for="status">Aktywna:</label>
            <input type="checkbox" name="status" id="status">
            <button type="submit" name="add">Dodaj</button>
          </form>';
}

function UsunPodstrone($id) {
    global $pdo;

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $pdo->prepare("DELETE FROM page_list WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        echo "<p>Podstrona została usunięta.</p>";
    }
}

echo "<h1>Panel administracyjny</h1>";
echo '<nav>
        <a href="?action=list">Lista podstron</a> | 
        <a href="?action=add">Dodaj nową podstronę</a> | 
        <a href="?action=logout">Wyloguj</a>
      </nav>';

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'list':
            ListaPodstron();
            break;
        case 'edit':
            if (isset($_GET['id'])) {
                EdytujPodstrone($_GET['id']);
            }
            break;
        case 'add':
            DodajNowaPodstrone();
            break;
        case 'delete':
            if (isset($_GET['id'])) {
                UsunPodstrone($_GET['id']);
            }
            break;
        case 'logout':
            session_destroy();
            header('Location: admin.php');
            break;
        default:
            echo "<p>Nieznana akcja.</p>";
            break;
    }
} else {
    ListaPodstron();
}
?>
