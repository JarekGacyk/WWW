<?php
echo "Ten plik został załadowany za pomocą require_once().<br>";


function funkcjaRequireOnce() {
    echo "Funkcja z pliku require_once została wywołana.<br>";
}
?>
