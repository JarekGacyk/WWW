<?php
echo "Ten plik został załadowany za pomocą include().<br>";


function funkcjaInclude() {
    echo "Funkcja z pliku include została wywołana.<br>";
}
?>
