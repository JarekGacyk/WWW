<?php
if (isset($_GET['idp'])) {
    $idp = htmlspecialchars($_GET['idp']); 
    $stmt = $pdo->prepare("SELECT page_title, page_content FROM page_list WHERE id = :idp AND status = 1 LIMIT 1");
    $stmt->execute(['idp' => $idp]);
    $page = $stmt->fetch();

    
} else {
    echo "<h1>Strona główna</h1>";
    echo "<p>Witaj na stronie głównej!</p>";
}
?>
