<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php'); 
	
    exit;
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Panel administracyjny</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <h1>Panel Administracyjny</h1>
    <nav>
        <ul>
            <li><a href="edit_pages.php">Edytuj Strony</a></li>
            <li><a href="logout.php">Wyloguj</a></li>
        </ul>
    </nav>
</body>
</html>
